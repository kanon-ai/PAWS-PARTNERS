﻿Expert 1.0.3 (local update)
・縮小画面でもクリア時にネコとウサギがジャンプします。家がCLEARの小窓に隠れる場合は小窓の下に表示します。
・SWAPの小さな状態表示を、通常タイルと同じ紫背景＋濃い緑/黄色に統一しました。
・ステージ、パスワード、判定、BGMは変更していません。
BlueMSX+を終了後、同梱XMLをDatabasesフォルダーの同名ファイルへ上書きし、再起動してください。

The friends now hop after clearing in the F5 overview. If their homes overlap the CLEAR window, they celebrate below it.
SWAP badges now use the same purple background and dark-green/yellow indicators as the full tile.
Stages, passwords, rules and music are unchanged.
Close BlueMSX+, replace the same-name XML in Databases with the included file, then restart.
Validated in openMSX MSX2 and TurboR profiles. This update is not runtime-tested in BlueMSX+ or on physical hardware.
