﻿PAWS PARTNERS Expert 1.0.2 - local inspection update

F5縮小画面でSHIFTを押しながら矢印キー：任意のマスの拡大確認。
SHIFTを離す：元の配置カーソルと実行・一時停止状態に戻ります。
BASEは床・仕掛け、CHIPは配置チップと状態表示です。
確認中はキャラクターを隠して進行を止めます。配置や解法は変わりません。

BlueMSX+を終了して、同梱paws-partners-expert-db.xmlをエミュレーターのDatabasesフォルダーへコピーしてください。
同名の古いXMLがある場合は今回のXMLへ置き換えてください。旧1.0.0/1.0.1の登録も含みます。
BlueMSX+を起動し、同梱ROMを開いてください。自動判別できない場合はROM種類ASCII8を選択できます。
パスワード、50面の内容、BGMは変更していません。

Hold SHIFT + arrows in F5 overview to inspect any cell. Release to restore the original cursor and run/pause state.
BASE shows the mechanism; CHIP shows the placed tile and badge. Actors are hidden and progress is held only while inspecting.
Close BlueMSX+, copy the included XML into its Databases folder (replace the older same-name file), then restart it and open this ROM.
Stage passwords, all 50 puzzles, and music are unchanged.

Validation: openMSX C-BIOS MSX2 EU / Panasonic FS-A1ST. Physical hardware not tested.
The XML SHA-1 entry matches the included ROM; BlueMSX+ runtime not re-tested for this update.
